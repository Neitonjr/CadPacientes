package com.example.cadpacientes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.DropBoxManager;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.cadpacientes.DBHelper.PacientesDB;
import com.example.cadpacientes.model.Pacientes;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lista;
    PacientesDB DBHelper;
    ArrayList<Pacientes> listview_Pacientes;
    Pacientes paciente;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCadastrar = (Button) findViewById(R.id.btn_Cadastrar);
        btnCadastrar.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, CadastroPacientes.class);
                startActivity(intent);
            }
        });

        lista = (ListView) findViewById(R.id.listview_Pacientes);
        registerForContextMenu(lista);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
                Pacientes pacienteEscolhido = (Pacientes) adapter.getItemAtPosition(position);

                Intent i = new Intent(MainActivity.this, CadastroPacientes.class);
                i.putExtra("paciente-escolhido", pacienteEscolhido);
            }
        });

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                paciente = (Pacientes) lista.getItemAtPosition(i);
                // era para ser delete
            }
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuItem menuDelete = menu.add("Deletar Este Paciente");
        menuDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
            public boolean onMenuItemClick(MenuItem item){
                DBHelper = new PacientesDB(MainActivity.this);
                DBHelper.deletarPaciente(paciente);
                DBHelper.close();
                carregarPaciente();
                return true;
            }
        });
    }

    protected void onResume(){
        super.onResume();
        carregarPaciente();
    }

    public void carregarPaciente(){
        DBHelper = new PacientesDB(MainActivity.this);
        listview_Pacientes = DBHelper.getLista();
        DBHelper.close();

        if(listview_Pacientes != null){
            adapter = new ArrayAdapter<Pacientes>(MainActivity.this, android.R.layout.simple_list_item_1, listview_Pacientes);
            lista.setAdapter(adapter);
        }
        //finish();
    }
}
