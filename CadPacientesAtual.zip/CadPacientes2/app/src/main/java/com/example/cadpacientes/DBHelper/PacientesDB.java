package com.example.cadpacientes.DBHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import com.example.cadpacientes.model.Pacientes;

import java.util.ArrayList;

public class PacientesDB extends SQLiteOpenHelper {

    private static final String DATABASE ="dbpacientes";
    private static final int VERSION = 1;

    public PacientesDB (Context context){
        super(context, DATABASE,null, VERSION );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String paciente = "CREATE TABLE pacientes(id INTERGER PRIMARY KEY AUTOINCREMENT NOT NULL, nomepaciente TEXT NOT NULL, endereco TEXT NOT NULL, telefone INTERGER, planosaude TEXT NOT NULL;";
        db.execSQL(paciente);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String paciente = "DROP TABLE IF EXISTS pacientes";
        db.execSQL(paciente);

    }

    // Lista - Salvar
    public void salvarPaciente(Pacientes paciente){
        ContentValues values = new ContentValues();

        values.put("nomepaciente",paciente.getNomePaciente());
        values.put("endereco",paciente.getEnderecoPaciente());
        values.put("telefone",paciente.getTelefonePaciente());
        values.put("planosaude",paciente.getPlanoSaude());

        getWritableDatabase().insert("pacientes",null,values);
    }

    // metodo alterar
    public void alterarPaciente(Pacientes paciente){
        ContentValues values = new ContentValues();

        values.put("nomepaciente",paciente.getNomePaciente());
        values.put("endereco",paciente.getEnderecoPaciente());
        values.put("telefone",paciente.getTelefonePaciente());
        values.put("planosaude",paciente.getPlanoSaude());

        String [] args = {paciente.getId().toString()};
        getWritableDatabase().update("pacientes",values,"id=?",args);
    }

    // metodo deletar
    public void deletarPaciente(Pacientes paciente){
        String [] args = {paciente.getId().toString()};
        getWritableDatabase().delete("pacientes","id=?",args);
    }

    // Lista - Mostrar
    public ArrayList<Pacientes> getLista(){
        String [] columns ={"id","nomepaciente","endereco","telefone","planosaude"};
        Cursor cursor = getWritableDatabase().query("pacientes",columns,null,null,null,null,null,null);
        ArrayList<Pacientes> pacientes = new ArrayList<Pacientes>();

        while (cursor.moveToNext()){
            Pacientes paciente = new Pacientes();
            paciente.setId(cursor.getLong(0));
            paciente.setNomePaciente(cursor.getString(1));
            paciente.setEnderecoPaciente(cursor.getString(2));
            paciente.setTelefonePaciente(cursor.getInt(3));
            paciente.setPlanoSaude(cursor.getString(4));

            pacientes.add(paciente);
        }
        return pacientes;
    }
}
