package com.example.cadpacientes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.cadpacientes.DBHelper.PacientesDB;
import com.example.cadpacientes.model.Pacientes;

public class CadastroPacientes extends AppCompatActivity {
    EditText editText_NomePaciente, editText_Endereco, editText_Telefone, editText_PlanoSaude;
    Button btn_Editar;
    Pacientes editarPaciente, paciente;
    PacientesDB DBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pacientes);

        paciente = new Pacientes();
        DBHelper = new PacientesDB(CadastroPacientes.this);

        Intent intent = getIntent();
        editarPaciente = (Pacientes) intent.getSerializableExtra("paciente-escolhido");

        editText_NomePaciente = (EditText) findViewById(R.id.editText_NomePaciente);
        editText_Endereco = (EditText) findViewById(R.id.editText_Endereco);
        editText_Telefone = (EditText) findViewById(R.id.editText_Telefone);
        editText_PlanoSaude = (EditText) findViewById(R.id.editText_PlanoSaude);

        btn_Editar = (Button) findViewById(R.id.btn_Editar);

        if (editarPaciente != null){
            btn_Editar.setText("Modificar");

            editText_NomePaciente.setText(editarPaciente.getNomePaciente());
            editText_Endereco.setText(editarPaciente.getEnderecoPaciente());
            editText_Telefone.setText(editarPaciente.getTelefonePaciente()+"");
            editText_PlanoSaude.setText(editarPaciente.getPlanoSaude());

            paciente.setId(editarPaciente.getId());


        }else{
            btn_Editar.setText("Cadastrar");
        }

        btn_Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paciente.setNomePaciente(editText_NomePaciente.getText().toString());
                paciente.setEnderecoPaciente(editText_Endereco.getText().toString());
                paciente.setTelefonePaciente(Integer.parseInt(editText_Telefone.getText().toString()));
                paciente.setPlanoSaude(editText_PlanoSaude.getText().toString());

                if (btn_Editar.getText().toString().equals("Cadastrar")){
                    DBHelper.salvarPaciente(paciente);
                    DBHelper.close();
                }else{
                    DBHelper.alterarPaciente(paciente);
                    DBHelper.close();
                }
            }
        });
    }
}
