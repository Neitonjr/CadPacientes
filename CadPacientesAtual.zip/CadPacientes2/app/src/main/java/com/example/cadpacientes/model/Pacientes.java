package com.example.cadpacientes.model;

import java.io.Serializable;

public class Pacientes implements Serializable {

    private Long id;
    private String nomePaciente;
    private String enderecoPaciente;
    private int telefonePaciente;
    private String planoSaude;

    public String toString(){
        return nomePaciente.toString();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public String getEnderecoPaciente() {
        return enderecoPaciente;
    }

    public void setEnderecoPaciente(String enderecoPaciente) {
        this.enderecoPaciente = enderecoPaciente;
    }

    public int getTelefonePaciente() {
        return telefonePaciente;
    }

    public void setTelefonePaciente(int telefonePaciente) {
        this.telefonePaciente = telefonePaciente;
    }

    public String getPlanoSaude() {
        return planoSaude;
    }

    public void setPlanoSaude(String planoSaude) {
        this.planoSaude = planoSaude;
    }
}
